//Torres Silva Alan Etienne
//Grupo 2SV2
//Examen extraordinario, programa para ejercicios de bisecci�n

#include <conio.h>
#include <iostream>
#include <math.h>
#include <fstream>
#define tol 0.05
using namespace std;

struct poli
{
       float a,b,c,d,e,f;
       void leer();
       void biseccion();
};

void poli::leer()
{
     cout<<"Dame el valor de A: ";
     cin>>a;
     cout<<"Dame el valor de B: ";
     cin>>b;
     cout<<"Dame el valor de C: ";
     cin>>c;
     cout<<"Dame el valor de D: ";
     cin>>d;
     cout<<"Dame el valor de E: ";
     cin>>e;
     cout<<"Dame el valor de F: ";
     cin>>f;
}

void poli::biseccion()
{
   float xr,xi=0,xl,xu,fxr,fxl,fxu,error=100;
   int i;
   
   cout<<"Dame un intervalo [a,b]"<<endl;
   cout<<"a= ";
   cin>>xl;
   cout<<"b= ";
   cin>>xu;
   
   cout<<a;
   cout<<b;
   cout<<c;
   cout<<d;
   cout<<e;
   cout<<f<<endl;
   
   xr=(xl+xu)/2;
   fxr=(a*pow(xr,5))+(b*pow(xr,4))+(c*pow(xr,3))+(d*pow(xr,2))+(e*xr)+f;
   cout<<fxr<<endl;
   fxl=(a*pow(xl,5))+(b*pow(xl,4))+(c*pow(xl,3))+(d*pow(xl,2))+(e*xl)+f;
   fxu=(a*pow(xu,5))+(b*pow(xu,4))+(c*pow(xu,3))+(d*pow(xu,2))+(e*xu)+f;
   
   printf("xl\txu\txr\tf(xl)\tf(xu)\tf(xr)\terror\n");  
   printf("%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n",xl,xu,xr,fxl,fxu,fxr,error);  
     if(fxr==0)
     {
         cout<<"La raiz es: "<<xr;
         getch();
         exit(0);
     }
     
     for(i=0;i<=100;i++)
     {
         xr=(xl+xu)/2;
         
         fxr=(a*pow(xr,5))+(b*pow(xr,4))+(c*pow(xr,3))+(d*pow(xr,2))+(e*xr)+f;
         fxl=(a*pow(xl,5))+(b*pow(xl,4))+(c*pow(xl,3))+(d*pow(xl,2))+(e*xl)+f;
         fxu=(a*pow(xu,5))+(b*pow(xu,4))+(c*pow(xu,3))+(d*pow(xu,2))+(e*xu)+f;
         printf("%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n",xl,xu,xr,fxr,fxl,fxu,error);
         
         if(fxr==0)
         break;
         else
         {
             
             if((fxl*fxr)<0)
             xu=xr; 
               
             if((fxu*fxr)<0)
             xl=xr;  
             
             error=fabs((xr-xi)*100/xr); 

          }
           
         xi=xr;
         if (error<tol)
         break;
     }
     
     if(error<tol)
     cout<<"La raiz es x= "<<xr;
     else
     cout<<"No hay raiz en el intervalo dado";
          
}

int main()
{
    poli a;
    a.leer();
    a.biseccion();
    
    getch();
    return 0;
}
