//Torres Silva Alan Etienne
//Grupo 2SV2
//Examen extraordinario, programa para metodo de Newton-Raphson

#include <iostream>
#include <conio.h>
#include <math.h>
#include <fstream>
#define tol 0.0001

using namespace std;

struct coef
{
       float A,B,C,D,E,F;
};

struct Datos
{
	float xi,fx,dfx,x,error;
};

Datos In = {0.0, 0.0, 0.0, 0.0, 0.0};

coef leer()
{
     coef L;
     cout<<"Dame el valor de A: ";
     cin>>L.A;
     cout<<"Dame el valor de B: ";
     cin>>L.B;
     cout<<"Dame el valor de C: ";
     cin>>L.C;
     cout<<"Dame el valor de D: ";
     cin>>L.D;
     cout<<"Dame el valor de E: ";
     cin>>L.E;
     cout<<"Dame el valor de F: ";
     cin>>L.F;
     return L;
}

class poli
{
      coef G;
      float x,fx,dfx,error,i,xi;
      double h;
      
      public: poli(){G=leer(); 
					 x=fx=dfx=0;
					 cout<<"Dame un punto inicial xi= ";
					 cin>>xi;
					}
              void Dato(float R){x=R;}
			  void newton_r();
              void calcval();
              void derivada();
              float regval(){return fx;}
              float regder(){return dfx;}

			  Datos datos_nwt();
};

class Nodo
{
      Datos B;
      Nodo *sig;
      
      public: Nodo (Datos C=In, Nodo *s=NULL)
              {
                  B=C;
                  sig=s;
              }

   void Captura(Datos R){B=R;}
   void ModSig (Nodo *p){sig=p;}

   Nodo *RegSig(){return(sig);}

   float RegValxi(){return (B.xi);}
   float RegValfx(){return (B.fx);}
   float RegValdfx(){return (B.dfx);}
   float RegValx(){return (B.x);}
   float RegValerror(){return (B.error);}
};


class LSE
{
      Nodo *st, *ed, *gen;
      
      public:LSE(){st=ed=gen=NULL;}
             void Insertar(Datos X); 
             void Print();
             void GuardarArc();
             void LeerArc();
};


void LSE::Insertar(Datos X)
{
     if(st==NULL)
     {
        gen= new Nodo(X);
        st=ed=gen;
     } 
     else
     {
        Nodo *aux=gen;
        gen=new Nodo(X);
        aux->ModSig(gen);
        ed=gen;
     }
}

void LSE::Print()
{
     for(Nodo *i=st; i!=NULL; i=i->RegSig())
     {
         cout<<"\n"<<i->RegValxi()<<"\t"<<i->RegValfx()<<"\t";
         cout<<i->RegValdfx()<<"\t"<<i->RegValx()<<"\t";
         cout<<i->RegValerror()<<endl;
     }
}

void LSE::GuardarArc()
{
   Nodo *p;
   ofstream arch;
   char nom[30];
 
   cout<<"\n Introduce nombre del archivo: "; 
   cin>>nom;
 
   arch.open(nom, ios::app);
   arch<<"\n Roman Gonzalez"<<endl;
   arch<<"\n Metodo de Newton-Raphson"<<endl;
   arch<<"xi"<<"\t"<<"fx"<<"\t"<<"dfx"<<"\t"<<"x"<<"\t"<<"error";
 
   for(p=st; p!=NULL; p=p->RegSig()) 
   {
      arch<<"\n"<<p->RegValxi()<<"\t"<<p->RegValfx()<<"\t"<<p->RegValdfx()
          <<"\t"<<p->RegValx()<<"\t"<<p->RegValerror()<<"\t";
   }
}

void poli::calcval()
{
     fx=G.A*pow(x,5)+G.B*pow(x,4)+G.C*pow(x,3)+
     G.D*pow(x,2)+G.E*x+G.F;
}

void poli::derivada()
{
     dfx=5*G.A*pow(x,4)+4*G.B*pow(x,3)+3*G.C*pow(x,2)+
     2*G.D*x+G.E;
}

void poli::newton_r() //xi ademas de ser el valor inicial sera el que cambiara durante cada iteracion
{
	Datos fila; //esta estructura tipo "Datos" se guarda en forma de fila en el archivo cuando es requerida
	LSE newton;	

	cout<<"xi\t x(i+1)\t fx\t dfx\t error"<<endl;
	
	for(i=0;i<=50;i++)
	{
		Dato(xi);
		calcval();
		fx=regval();
		derivada();
		dfx=regder();
		x=xi-(fx/dfx);
		error=fabs((x-xi)*100/x);//hasta este punto se calculan la derivada y la funcion evaluadas en el punto incial
		cout<<xi<<"\t"<<fx<<"\t"<<dfx<<"\t"<<x<<"\t"<<error<<endl;

		fila=datos_nwt();
		newton.Insertar(fila);

		if(error<tol)
		{
			cout<<"La raiz es x= "<<xi;
			break;
		}

		xi=x; //el valor de la variable xi cambia para usarse en la siguiente  iteracion
	}

	if(error<tol)
	newton.GuardarArc();
	else
	{
		cout<<"No hay raiz cerca del punto dado o la raiz es x=0\t"; //el archivo no se guardara si no se encontro la raiz
	}

}

Datos poli::datos_nwt() //esta funcion guarda los datos de cada iteracion
{
   Datos fila;
   fila.xi=xi;
   fila.fx=fx;
   fila.dfx=dfx;
   fila.x=x;
   fila.error=error;
   return fila;
}

int main()
{
    system("color 1f");
    poli A;

	A.newton_r();
    
    getch();
    return 0;
}
