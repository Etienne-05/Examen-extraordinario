//Torres Silva Alan Etienne
//Grupo 2SV2
//Examen extraordinario, punto fijo

#include <iostream>
#include <conio.h>
#include <math.h>
#include <fstream>
#define tol 0.005

using namespace std;

struct coef
{
       float A,B,C,D,E,F;
};

struct Datos//estructura para agregar una fila de datos en la tabla de resultados
{
	float xi,fx,error;
};

Datos In = {0.0, 0.0, 0.0};

coef leer()
{
     coef L;
     cout<<"Dame el valor de A: ";
     cin>>L.A;
     cout<<"Dame el valor de B: ";
     cin>>L.B;
     cout<<"Dame el valor de C: ";
     cin>>L.C;
     cout<<"Dame el valor de D: ";
     cin>>L.D;
     cout<<"Dame el valor de E: ";
     cin>>L.E;
     cout<<"Dame el valor de F: ";
     cin>>L.F;
     return L;
}

class poli
{
      coef G;
      float x,x0,fx,error,i;
      char op;
      
      public: poli(){G=leer(); x=x0=fx=0;  error=100;
						cout<<"Dame un punto inicial: \n";
						cout<<"xi= ";
						cin>>x;
						system("cls");
						despejar();
					}
              void Dato(float R){x=R;}
              void calcval();
              void despejar();
			  void punto_fijo();
			  Datos datos_pf();
              float regval(){return fx;}
};

class Nodo
{
      Datos B;
      Nodo *sig;
      
      public: Nodo (Datos C=In, Nodo *s=NULL)
              {
                  B=C;
                  sig=s;
              }

   void Captura(Datos R){B=R;}
   void ModSig (Nodo *p){sig=p;}

   Nodo *RegSig(){return(sig);}

   float RegValxi(){return (B.xi);}
   float RegValfx(){return (B.fx);}
   float RegValerror(){return (B.error);}
};


class LSE
{
      Nodo *st, *ed, *gen;
      
      public:LSE(){st=ed=gen=NULL;}
             void Insertar(Datos X); 
             void Print();
             void GuardarArc();
             void LeerArc();
};


void LSE::Insertar(Datos X)
{
     if(st==NULL)
     {
        gen= new Nodo(X);
        st=ed=gen;
     } 
     else
     {
        Nodo *aux=gen;
        gen=new Nodo(X);
        aux->ModSig(gen);
        ed=gen;
     }
}

void LSE::Print()
{
     for(Nodo *i=st; i!=NULL; i=i->RegSig())
     {
         cout<<"\n"<<i->RegValxi()<<"\t"
             <<i->RegValfx()<<"\t";
         cout<<i->RegValerror()<<endl;
     }
}

void LSE::GuardarArc()
{
   Nodo *p;
   ofstream arch;
   char nom[30];
 
   cout<<"\n Introduce nombre del archivo: "; 
   cin>>nom;
 
   arch.open(nom, ios::app);
   arch<<"\n Roman Gonzalez"<<endl;
   arch<<"\n Metodo de punto fijo"<<endl;
   arch<<"xi"<<"\t"<<"f(x)"<<"\t"<<"error";
 
   for(p=st; p!=NULL; p=p->RegSig()) 
   {
      arch<<"\n"<<p->RegValxi()<<"\t"<<p->RegValfx()
          <<"\t"<<p->RegValerror()<<"\t";
   }
}

void poli::despejar()
{
	 cout<<"A quien despejar?\n";
	 cout<<"1: x\n";
	 cout<<"2: x^2\n";
	 cout<<"3: x^3\n";
	 cout<<"4: x^4\n";
	 cout<<"5: x^5\n";
	 op=getch();
}

void poli::calcval()
{
     switch(op)
     {
         case '1': if(G.E==0)//para despejar x
                   {
                      cout<<"\nE=0, eliga otra icognita."; getch();
                      system("cls");
                      despejar();
                   }
                   
                   else
                   fx=(G.A*pow(x,5)+G.B*pow(x,4)+G.C*pow(x,3)+
                   G.D*pow(x,2)+G.F)/-G.E;
                   

         break;
         
         case '2': if(G.D==0)//para despejar x^2
                   {
                      cout<<"\nD=0, eliga otra icognita."; getch();
                      system("cls");
                      despejar();
                   }
                   else
                   {
                       fx=(G.A*pow(x,5)+G.B*pow(x,4)+G.C*pow(x,3)
                       +G.E*x+G.F)/-G.D;
                       fx=pow(fx,(1/2.0));
                   }
         break;
         
         case '3': if(G.C==0)//para despejar x^3
                   {
                      cout<<"\nC=0, eliga otra icognita."; getch();
                      system("cls");
                      despejar();
                   }
                   else
                   {
                      fx=(G.A*pow(x,5)+G.B*pow(x,4)+
                      G.D*pow(x,2)+G.E*x+G.F)/-G.C;
                      fx=pow(fx,(1/3.0));
                   }
         break;
         
         case '4': if(G.B==0)//para despejar x^4
                   {
                      cout<<"\nB=0, eliga otra icognita."; getch();
                      system("cls");
                      despejar();
                   }
                   else
                   {
                      fx=(G.A*pow(x,5)+G.C*pow(x,3)+
                      G.D*pow(x,2)+G.E*x+G.F)/-G.B;
                      fx=pow(fx,(1/4.0));
                   }
         break;
        
         case '5': if(G.A==0)//para despejar x^5
                   {
                      cout<<"\nA=0, eliga otra icognita.";
                      getch();
                      system("cls");
                      despejar();
                   }
                   else
                   {
                      fx=(G.B*pow(x,4)+G.C*pow(x,3)+
                      G.D*pow(x,2)+G.E*x+G.F)/-G.A;
                      fx=pow(fx,(1/5.0));
                   }
         break;
     };
}

void poli::punto_fijo()
{
	LSE datos;
	Datos fila; //esta estructura se encarga de guardar una fila de datos en la tabla de resultados
	Dato(x);
	calcval();
	cout<<"xi\tf(x)\terror"<<endl;
	cout<<x<<"\t"<<x0<<"\t"<<error<<endl;
	
	for(i=0;i<=50;i++)
	{
		Dato(x);
		calcval();
		x=regval();
		error=fabs((x-x0)*100/x);
		cout<<x<<"\t"<<x0<<"\t"<<error<<endl;
		x0=regval();
		
		fila=datos_pf();
		datos.Insertar(fila);
		
		if(error<tol)
	    {
            break;
            cout<<"La raiz es x= "<<x<<endl;
        }
			
	}

	if(error<tol)
	{
		cout<<"La raiz es x= "<<x<<endl;
        datos.GuardarArc(); //el archivo se guardara solamente si se hallo una raiz
	}
	
	else
	{
		cout<<"No hay raiz cerca del punto dado\n"; 
        //si no se encontro alguna raiz el archivo no sera guardado
	}
}

Datos poli::datos_pf()
{
   Datos fila;
   fila.xi=x;
   fila.fx=fx;
   fila.error=error;
   return fila;
}

int main()
{
    system("color 1f");
    poli A;
	A.punto_fijo();
    
    getch();
    return 0;
}
